# Results of analyses

The final results from a given analyses will be stored here. Ideally, use a set
of directories corresponding to the scripts in the `code` directory that
generated the files (e.g. the script `/code/s01_process_data.R` will save to
`results/s01_process_data`). This approach makes it easy to track where
results come from.
