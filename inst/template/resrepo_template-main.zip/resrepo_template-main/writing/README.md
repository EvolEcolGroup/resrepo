# Writing

If you want to work collaboratively and write up your reserach on GoogleDocs or
Word365, just store the links to those documents in a markdown document (.md)
stored in this directory.